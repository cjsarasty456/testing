import * as React from 'react'
import { Text, View } from 'react-native'

export default function App() {

  return (
    <View>
      <Text>Hola</Text>

      <Text>Open up App.tsx to start working on your app!</Text>
    </View>
  )
}
